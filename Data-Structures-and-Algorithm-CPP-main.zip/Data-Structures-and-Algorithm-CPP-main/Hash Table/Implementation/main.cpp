#include <iostream>
#include <cstdlib>
#include <string>

#include "hash.h"

int main()
{
	hash Mulai;
	Mulai.mainProgram();
	return 0;
}